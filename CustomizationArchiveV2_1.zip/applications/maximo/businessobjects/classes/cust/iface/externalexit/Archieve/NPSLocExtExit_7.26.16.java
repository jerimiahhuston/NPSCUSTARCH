package cust.iface.externalexit;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Iterator;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.filter.*;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import psdi.iface.mic.MicUtil;
import psdi.iface.mic.StructureData;
import psdi.iface.mos.MOSStAXStructure;
import psdi.iface.mx6x.UpgradeXMLConverterOut;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.security.ConnectionKey;
import psdi.server.DBManager;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.MXFormat;
import psdi.iface.migexits.ExternalExit;


/**
 * @author Haq Khan
 *
 */
public class NPSLocExtExit extends ExternalExit {

	public NPSLocExtExit() {
		super();
	}

	/**
	 * FBMSIF504 outbound message processing.
	 * Ported DB Trigger MAXIMO.TR_INSERT_FBMS504_LOC to Java code.
	 * 
	 * @see cust.iface.externalexit.NPSExternalExit#setDataOut(psdi.iface.mic.StructureData)
	 */
	public StructureData setDataOut(StructureData exitData) throws MXException, RemoteException {
		//JM - added for MX 7.5
		exitData.breakData();
		String location = exitData.getCurrentData("LOCATION");
		String siteid = exitData.getCurrentData("SITEID");
		String type = exitData.getCurrentData("TYPE");
		String propertyid = exitData.getCurrentData("PROPERTYID");
		String lo8 = exitData.getCurrentData("LO8");
		Integer lo5 = exitData.getCurrentDataAsInt("LO5");
		//Need to add these fields in future as per FBMS to FMSS Mapping document requirement, 4/23/15 cpatel
		//HAQ - FRD 2.1.8 and 2.1.9
		//String utilization = exitData.getCurrentData("UTIL");
		//String beginlat = exitData.getCurrentData("LATIT");
		//String beginlong = exitData.getCurrentData("LONGIT");
		//String endlat = exitData.getCurrentData("LATIT2");
		//String endlong = exitData.getCurrentData("LONGIT2");
		
		StructureData sData = null;
		
		MboSetRemote frppSet = getMboSet("FRPP");
		frppSet.setWhere("LOCATION = '"+location+"' and SITEID = '"+siteid+"'");
		frppSet.reset();
		MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...Starting process");
		if (!frppSet.isEmpty()) {
			MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...frppSet NOT empty");
			MboRemote frpp = frppSet.getMbo(0);
			if (type.equalsIgnoreCase("OPERATING") && propertyid != null && !propertyid.equals("")) {
				MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...status and properyid check passed");
				MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...checking with lo5: " + lo5);
				MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...checking with frpp.getDouble('EX12'): " + frpp.getDouble("EX12") );
				//if (lo5 != 0 && frpp.getDouble("EX12") != 0) {
				if (lo5 != null && !lo5.equals("") && frpp.getDouble("EX12") != 0) {
					MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...lo5 and frpp.ex12 check passed");
					String condcode = null;
					if (lo8 != null && !lo8.equals("")) {
						if (lo8.equalsIgnoreCase("GOOD")) 
							condcode = "GOOD";
						if (lo8.equalsIgnoreCase("FAIR")) 
							condcode = "FAIR";
						if (lo8.equalsIgnoreCase("SERIOUS") || lo8.equalsIgnoreCase("POOR")) 
							condcode = "POOR";
						if (lo8.equalsIgnoreCase("NR") || lo8.equalsIgnoreCase("NE")) 
							condcode = "NE";
					}
					double frppfci = 0;
					String utilization = frpp.getString("UTIL");
					//HAQ - FRD 2.1.8 and 2.1.9
					//if (utilization.equalsIgnoreCase("Over Utilized")) {
					//	utilization = "Utilized";
					//}
					if (utilization.equalsIgnoreCase("Utilized") || utilization.equalsIgnoreCase("Over Utilized")) {
						utilization = "6";
					}
					if (utilization.equalsIgnoreCase("Unutilized")) {
						utilization = "5";
					}
					if (utilization.equalsIgnoreCase("Under Utilized")) {
						utilization = "7";
					}
					
					//HAQ - FRD 2.1.8 and 2.1.9
					String beginlat = frpp.getString("LATIT");
					String beginlong = frpp.getString("LONGIT");
					String endlat = frpp.getString("LATIT2");
					String endlong = frpp.getString("LONGIT2");
					
					if (frpp.getDouble("FRPPFCI") >= 0 && frpp.getDouble("FRPPFCI") <= 1)
						frppfci = frpp.getDouble("FRPPFCI");
					
					MboSetRemote FBMSIF504Set = getMboSet("FBMSIF504");
					MboRemote newMbo = FBMSIF504Set.add();
					newMbo.setValue("maximoid", "P"+location);
					//newMbo.setValue("hasld", 0);
					newMbo.setValue("propertyid", propertyid);
					newMbo.setValue("api", Integer.toString(lo5));
					newMbo.setValue("crv", frpp.getDouble("EX12"));
					newMbo.setValue("fci", frppfci);
					newMbo.setValue("condcode", condcode);
					newMbo.setValue("transdate", MXServer.getMXServer().getDate());
					newMbo.setValue("deferred_maint", frpp.getDouble("EX11"));
					newMbo.setValue("pm2", frpp.getDouble("EX10"));
					newMbo.setValue("pm3", frpp.getString("EVAL"));
					newMbo.setValue("bureau", "P000");
					//Need to add these fields in future as per FBMS to FMSS Mapping document requirement, 7/29/15 cpatel
					//HAQ - FRD 2.1.8 and 2.1.9
					newMbo.setValue("utilization", utilization);
					newMbo.setValue("beginlat", beginlat);
					newMbo.setValue("beginlong", beginlong);
					newMbo.setValue("endlat", endlat);
					newMbo.setValue("endlong", endlong);
					
					newMbo.setValue("description", exitData.getCurrentData("DESCRIPTION"));
					
					FBMSIF504Set.save();
					MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...saved FBMSIF504Set");
					//CreateStructure cs = new CreateStructure("FBMSIF504INTOP", null, this, getUserInfo());
					//sData = cs.create(newMbo);
					
					//Updated for Maximo 7.5 150402 JM
					//Updated to change from "Sync" to "Publish" as per SAP request, cpatel
					sData = new StructureData("Publish", "FBMSIF504INTO","EN", 1, false, false);
					sData.setCurrentMbo(newMbo);
					
					//Set values for new StructureData (cannot seem to find automatic way of setting, so setting manually
					sData.setCurrentData("FBMSIF504ID", newMbo.getLong("FBMSIF504ID"));
					sData.setCurrentData("MAXIMOID", "P"+location);
					sData.setCurrentData("PROPERTYID", propertyid);
					sData.setCurrentData("API", Integer.toString(lo5));
					sData.setCurrentData("CONDCODE", condcode);
					sData.setCurrentData("PM2", frpp.getDouble("EX10"));
					sData.setCurrentData("DEFERRED_MAINT", frpp.getDouble("EX11"));
					sData.setCurrentData("FCI", frppfci);
					sData.setCurrentData("CA", newMbo.getString("CA"));
					sData.setCurrentData("LASTCCA", newMbo.getString("LASTCCA"));
					sData.setCurrentData("PM3", frpp.getString("EVAL"));
					//sData.setCurrentData("MAINTRESP", frpp.getString("MAINTRESP"));
					//sData.setCurrentData("RAC", frpp.getString("RAC"));
					String crv = frpp.getString("EX12");
					crv = crv.replace(",","");					
					sData.setCurrentData("CRV", crv);
					sData.setCurrentData("BUREAU", newMbo.getString("BUREAU"));
					//Need to add these fields in future as per FBMS to FMSS Mapping document requirement, 4/23/15 cpatel
					//HAQ - FRD 2.1.8 and 2.1.9
					sData.setCurrentData("UTILIZATION", utilization);
					sData.setCurrentData("BEGINLAT", beginlat);
					sData.setCurrentData("ENDLAT", endlat);
					sData.setCurrentData("BEGINLONG", beginlong);
					sData.setCurrentData("ENDLONG", endlong);
					//sData.setCurrentData("STREET", newMbo.getString("STREET"));
					//sData.setCurrentData("HOUSENUM", newMbo.getString("HOUSENUM"));
					//sData.setCurrentData("ZIPCODE", newMbo.getString("ZIPCODE"));
					//sData.setCurrentData("COUNTY", newMbo.getString("COUNTY"));
					//sData.setCurrentData("STATE", newMbo.getString("STATE"));
					//sData.setCurrentData("MEAS_TYPE", newMbo.getString("MEAS_TYPE"));
					//sData.setCurrentData("MEAS_UNIT", newMbo.getString("MEAS_UNIT"));
					//sData.setCurrentData("MEAS_DATE_FROM", newMbo.getString("MEAS_DATE_FROM"));
					//sData.setCurrentData("MEAS_DATE_TO", newMbo.getString("MEAS_DATE_TO"));
					//sData.setCurrentData("DISP_OBST_CODE", newMbo.getString("DISP_OBST_CODE"));
					//sData.setCurrentData("CREATEDATE", newMbo.getString("CREATEDATE"));
					sData.setCurrentData("DESCRIPTION", exitData.getCurrentData("DESCRIPTION"));
					//sData.setCurrentData("STATUS", newMbo.getString("STATUS"));
					//sData.setCurrentData("HASLD", newMbo.getString("HASLD"));
					//Set values for new StructureData (cannot seem to find automatic way of setting, so setting manually
					
					//Document userDoc = sData.getData();
					//This code produces null pointer exception, cpatel
					//userDoc = UpgradeXMLConverterOut.convertTo6X(userDoc, false, "FBMSIF504INTO", "FBMSES");
					//Removed as message tracking functionality is available in Maximo 7.5, cpatel 7/1/15
					//logOutboundXml(exitData.getMessageID(), userDoc);
					//sData = new StructureData(userDoc);
					MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...logged message");
					
				} else { 
					MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "....lo5 and frpp.ex12 check failed. About to throw exception");
					throw new MXApplicationException("iface", "skip_transaction");
				 }
			} else { 
				MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...status and properyid check failed. About to throw exception");
				throw new MXApplicationException("iface", "skip_transaction");
			 }
		} else {
			MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...frppSet is empty. About to throw exception");
			throw new MXApplicationException("iface", "skip_transaction");
		}
		MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...Returning sData");
		return sData;
	}

	
	/**
	 * FBMSIF505 inbound message processing.
	 * 
	 * @see cust.iface.externalexit.NPSExternalExit#setDataIn(psdi.iface.mic.StructureData)
	 */
	public StructureData setDataIn(StructureData exitData) throws MXException, RemoteException {
		//HAQ - added for MX 7.5
		exitData.breakData();
		Document userDoc = exitData.getData();
		//Removed as message tracking functionality is available in Maximo 7.5, cpatel 7/1/15
		//logInboundXml(exitData.getMessageID(), userDoc);
		MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...logged message");
		
		String siteid = "";
		String propertyid = exitData.getCurrentData("PROPERTYID");		
		//Added validation for nullpointer exception, cpatel
		String maximoid;
		if(!exitData.isCurrentDataNull("MAXIMOID"))
		{
			maximoid = exitData.getCurrentData("MAXIMOID").substring(1, exitData.getCurrentData("MAXIMOID").length());
		}
        else
		{
			maximoid = "";
		}		
		String locstat = "";
		String uom = "";
		String legalin = "";
		String type_flag = "x";
		String email_subj = "";
		String email_msge = "";
		String locdesc = "";
		String locstatus = "";
		int outgrant = 0;
		double qty = 0.0;
		try {
			DBManager dbm = MXServer.getMXServer().getDBManager();
			ConnectionKey ck = userInfo.getConnectionKey();
			Connection conn = dbm.getConnection(ck);
			Statement stmt = conn.createStatement();
			ResultSet resultSet = stmt.executeQuery("select siteid from busent_palpha_lookup where busent = substr('"+propertyid+"',7,8)");
			int i = 0;
			MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...Connecting to DB and getting resultset");
			while (resultSet.next()) {
				i++;
				siteid = resultSet.getString(1);
			}
			if (i == 1) {
				if (!exitData.isCurrentDataNull("MAXIMOID")) {
					MboSetRemote locationSet = getMboSet("LOCATIONS");
					locationSet.setWhere("LOCATION = '"+maximoid+"' and SITEID = '"+siteid+"' and propertyid = '"+propertyid+"'");
					locationSet.reset();
					if (locationSet.count() == 1) {
						locdesc = locationSet.getMbo(0).getString("DESCRIPTION");
						locstatus = locationSet.getMbo(0).getString("STATUS");
						MboSetRemote fbmslocholdSet = getMboSet("FBMSLOCHOLD");
						fbmslocholdSet.setWhere("LOCATION = '"+maximoid+"' and SITEID = '"+siteid+"' and processflag = 'N'");
						fbmslocholdSet.reset();
						if (fbmslocholdSet.count() > 0) {
							for (int j = 0; j < fbmslocholdSet.count(); j++) {
								MboRemote fbmslochold = fbmslocholdSet.getMbo(j);
								fbmslochold.setValue("PROCESSFLAG", "D", 11L);
							}
							fbmslocholdSet.save();
							fbmslocholdSet.close();
							MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...after completing fbmslocholdSet.save()");
						}
					} else {
						MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...Locations Set is empty. About to throw exception");
						throw new MXApplicationException("iface", "skip_transaction");
					}
					if (!exitData.isCurrentDataNull("STATUSIND")) {
						if (exitData.getCurrentData("STATUSIND").equalsIgnoreCase("A")) 
							locstat = "OPERATING";
						if (exitData.getCurrentData("STATUSIND").equalsIgnoreCase("I")) 
							locstat = "INACTIVE";
						if (exitData.getCurrentData("STATUSIND").equalsIgnoreCase("D")) 
							locstat = "DECOMMISSIONED";
						if (exitData.getCurrentData("STATUSIND").equalsIgnoreCase("E") || exitData.getCurrentData("STATUSIND").equalsIgnoreCase("B") || exitData.getCurrentData("STATUSIND").equalsIgnoreCase("C")
							|| exitData.getCurrentData("STATUSIND").equalsIgnoreCase("F") || exitData.getCurrentData("STATUSIND").equalsIgnoreCase("S") || exitData.getCurrentData("STATUSIND").equalsIgnoreCase("G")) 
							locstat = "EXCESS";
					}
				}

				if (!exitData.isCurrentDataNull("EACH")) {
					qty = exitData.getCurrentDataAsDouble("EACH");
					uom = "EA";
				}
				if (!exitData.isCurrentDataNull("GSF")) {
					qty = exitData.getCurrentDataAsDouble("GSF");
					uom = "GSF";
				}
				if (!exitData.isCurrentDataNull("LINEARFEET")) {
					qty = exitData.getCurrentDataAsDouble("LINEARFEET");
					uom = "LF";
				}
				if (!exitData.isCurrentDataNull("LANEMILES")) {
					qty = exitData.getCurrentDataAsDouble("LANEMILES");
					uom = "LM";
				}
				if (!exitData.isCurrentDataNull("MILES")) {
					qty = exitData.getCurrentDataAsDouble("MILES");
					uom = "MI";
				}
				if (!exitData.isCurrentDataNull("SQYARDS")) {
					qty = exitData.getCurrentDataAsDouble("SQYARDS");
					uom = "SY";
				}
				
				//Changed from "legalintind" to "LEGALINTERESTINDICATOR", cpatel
				if (!exitData.isCurrentDataNull("LEGALINTERESTINDICATOR")) {
					if (exitData.getCurrentData("LEGALINTERESTINDICATOR").equalsIgnoreCase("F")) 
						legalin = "Foreign Owned";
					if (exitData.getCurrentData("LEGALINTERESTINDICATOR").equalsIgnoreCase("G")) 
						legalin = "Fed Owned";
					if (exitData.getCurrentData("LEGALINTERESTINDICATOR").equalsIgnoreCase("L")) 
						legalin = "Fed Leased";
					if (exitData.getCurrentData("LEGALINTERESTINDICATOR").equalsIgnoreCase("M")) 
						legalin = "Museum Trust";
					if (exitData.getCurrentData("LEGALINTERESTINDICATOR").equalsIgnoreCase("S")) 
						legalin = "State Owned";
					if (exitData.getCurrentData("LEGALINTERESTINDICATOR").equalsIgnoreCase("X")) 
						legalin = "GSA Provided";
					if (exitData.getCurrentData("LEGALINTERESTINDICATOR").equalsIgnoreCase("Y")) 
						legalin = "Other Agency Owned";
					if (exitData.getCurrentData("LEGALINTERESTINDICATOR").equalsIgnoreCase("Z")) 
						legalin = "Grant/Cooperative";
				} else {
					legalin = "Fed Owned";
				}
				
				if (!exitData.isCurrentDataNull("OUTGRANTINDICATOR")) {
					if (exitData.getCurrentData("OUTGRANTINDICATOR").equalsIgnoreCase("Y")) 
						outgrant = 1;
					if (exitData.getCurrentData("OUTGRANTINDICATOR").equalsIgnoreCase("N")) 
						outgrant = 0;
					if (exitData.getCurrentData("OUTGRANTINDICATOR").equalsIgnoreCase("Y")) 
						outgrant = 1;
				}
				
				if (exitData.isCurrentDataNull("MAXIMOID")) {
					type_flag = "n";
					locdesc = exitData.getCurrentData("description");
					email_subj = "A new location has been sent from FBMS to FMSS.";
					email_msge = "A new location has been sent from FBMS to FMSS. Please login to FMSS and review this location in the Locations ";
					email_msge += "application. In the 'Holding Table' tab you will be able to accept this new location or match ";
					email_msge += "it to an existing planned location. The following location was sent to FMSS for process: \n";
					email_msge += "Location Description: "+locdesc+"\n";
					email_msge += "FBMS ID: "+exitData.getCurrentData("PROPERTYID")+" \n";
					email_msge += "If you have any questions please contact the FMP Help Desk.";
				} else {
					if (locstat.equalsIgnoreCase("DECOMMISSIONED")) {
						type_flag = "d";
						email_subj = "A location that needs to be disposed of has been sent from FBMS to FMSS.";
						email_msge = "A location has been sent from FBMS to FMSS for disposal. Please login to FMSS and review this location in the ";
						email_msge += "Locations application. In the 'Holding Table' tab you will be able to change the status of this location ";
						email_msge += "to 'REMOVED'. The following location was sent to FMSS for process: \n";
						email_msge += "Location: "+exitData.getCurrentData("MAXIMOID")+"-"+locdesc+ "\n";
						email_msge += "FBMS ID: "+exitData.getCurrentData("PROPERTYID")+" \n";
						email_msge += "If you have any questions please contact the FMP Help Desk.";
					}
					if ((locstat.equalsIgnoreCase("OPERATING") || locstat.equalsIgnoreCase("INACTIVE") || locstat.equalsIgnoreCase("EXCESS")) && locstatus.equalsIgnoreCase("FBMS_ACT")) {
						type_flag = "u";
						email_subj = "A location that needs to be changed to a status of OPERATING, INACTIVE or EXCESS has been sent from FBMS to FMSS. A location ";
						email_msge = "has been sent from FBMS to FMSS for status change to OPERATING, INACTIVE or EXCESS. Please login to FMSS and review this ";
						email_msge += "location in the Locations application. In the 'Holding Table' tab you will be able to change the status of this ";
						email_msge += "location to the appropriate value. The following location was sent to FMSS for process: \n";
						email_msge += "Location: "+exitData.getCurrentData("MAXIMOID")+"-"+locdesc+ "\n";
						email_msge += "FBMS ID: "+exitData.getCurrentData("PROPERTYID")+" \n";
						email_msge += "If you have any questions please contact the FMP Help Desk.";
					}
				}
				
				if ("n,d,u".indexOf(type_flag) > -1) {
					/* This code generates error, 'EMAILLOCATION' is not a procedure or is undefined. This function is not important at this stage. cpatel
					CallableStatement cstmt = conn.prepareCall("{ call emaillocation(?, ?, ?, ?) }");
					MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...after calling DB Stored Proc emaillocation()");
					cstmt.setString(1,maximoid);
					cstmt.setString(2,locdesc);
					cstmt.setString(3,email_subj);
					cstmt.setString(4,email_msge);
					cstmt.execute();
					//cstmt.close();
					*/
					MboSetRemote fbmslocholdSet = getMboSet("FBMSLOCHOLD");
					MboRemote newMbo = fbmslocholdSet.add();
					//Change date formate for some fields as they are not set as DATE in database. cpatel
					newMbo.setValue("acqdate", exitData.getCurrentData("ACQDATE"));					
					newMbo.setValue("createby", exitData.getCurrentData("CREATEBY"));
					//Added validation, cpatel
					if(!exitData.isCurrentDataNull("CREATEDATE"))
						newMbo.setValue("createdate", exitData.getCurrentDataAsDate("CREATEDATE"));
					//SR 27602, cpatel
					//newMbo.setValue("description", exitData.getCurrentData("DESCRIPTION"));
					//Change date formate for some fields as they are not set as DATE in database. cpatel
					newMbo.setValue("disposaldate", exitData.getCurrentData("DISPOSALDATE"));
					newMbo.setValue("dispositionmethod", exitData.getCurrentData("DISPOSITIONMETHOD"));
					newMbo.setValue("doiassetcode", exitData.getCurrentData("DOIASSETCODE"));
					newMbo.setValue("each", exitData.getCurrentDataAsDouble("EACH"));
					//fbmslocholdid,
					newMbo.setValue("frppind", exitData.getCurrentDataAsInt("FRPPIND"));
					newMbo.setValue("gsf", exitData.getCurrentDataAsDouble("GSF"));
					//hasld,
					newMbo.setValue("installationid", exitData.getCurrentData("INSTALLATIONID"));
					newMbo.setValue("lanemiles", exitData.getCurrentDataAsDouble("LANEMILES"));
					newMbo.setValue("legacyid", exitData.getCurrentData("LEGACYID"));
					//newMbo.setValue("legalintind", exitData.getCurrentData(""));
					newMbo.setValue("linearfeet", exitData.getCurrentDataAsDouble("LINEARFEET"));
					newMbo.setValue("location", maximoid);
					newMbo.setValue("miles", exitData.getCurrentDataAsDouble("MILES"));
					newMbo.setValue("outgrantindicator", exitData.getCurrentData("OUTGRANTINDICATOR"));
					newMbo.setValue("propertyid", exitData.getCurrentData("PROPERTYID"));
					newMbo.setValue("realpropertyid", exitData.getCurrentData("REALPROPERTYID"));
					newMbo.setValue("reportingagency", exitData.getCurrentData("REPORTINGAGENCY"));
					newMbo.setValue("siteid", siteid);
					newMbo.setValue("sqyards", exitData.getCurrentDataAsDouble("SQYARDS"));
					newMbo.setValue("transdate", MXServer.getMXServer().getDate());
					newMbo.setValue("usingorg", exitData.getCurrentData("USINGORG"));
					newMbo.setValue("yearbuilt", exitData.getCurrentData("YEARBUILT"));
					newMbo.setValue("statusind", exitData.getCurrentData("STATUSIND"));
					newMbo.setValue("isvalid", exitData.getCurrentDataAsInt("ISVALID"));
					newMbo.setValue("processflag", "N");
					newMbo.setValue("acres", exitData.getCurrentDataAsDouble("ACRES"));
					newMbo.setValue("annualoperatingcost", exitData.getCurrentDataAsDouble("ANNUALOPERATINGCOST"));
					newMbo.setValue("changeby", exitData.getCurrentData("CHANGEBY"));
					//Added validation, cpatel
					if(!exitData.isCurrentDataNull("CHANGEDATE"))
						newMbo.setValue("changedate", exitData.getCurrentDataAsDate("CHANGEDATE"));
					newMbo.setValue("city", exitData.getCurrentData("CITY"));
					newMbo.setValue("congdistrict", exitData.getCurrentData("CONGDISTRICT"));
					newMbo.setValue("congdistrict2", exitData.getCurrentData("CONGDISTRICT2"));
					newMbo.setValue("congdistrict3", exitData.getCurrentData("CONGDISTRICT3"));
					newMbo.setValue("costcenter", exitData.getCurrentData("COSTCENTER"));
					newMbo.setValue("county", exitData.getCurrentData("COUNTY"));
					newMbo.setValue("disposalobstacle", exitData.getCurrentData("DISPOSALOBSTACLE"));
					newMbo.setValue("disposalstatuscode", exitData.getCurrentData("DISPOSALSTATUSCODE"));
					newMbo.setValue("fbmsuseremail", exitData.getCurrentData("FBMSUSEREMAIL"));
					newMbo.setValue("fbmsuserid", exitData.getCurrentData("FBMSUSERID"));
					newMbo.setValue("gsautilization", exitData.getCurrentData("GSAUTILIZATION"));
					newMbo.setValue("historicalstatus", exitData.getCurrentData("HISTORICALSTATUS"));
					newMbo.setValue("respcostcenter", exitData.getCurrentData("RESPCOSTCENTER"));
					newMbo.setValue("respcostcentername", exitData.getCurrentData("RESPCOSTCENTERNAME"));
					newMbo.setValue("state", exitData.getCurrentData("STATE"));
					newMbo.setValue("street", exitData.getCurrentData("STREET"));
					newMbo.setValue("sustainability", exitData.getCurrentData("SUSTAINABILITY"));
					newMbo.setValue("urbanacres", exitData.getCurrentDataAsDouble("URBANACRES"));
					newMbo.setValue("usefullife", exitData.getCurrentDataAsDouble("USEFULLIFE"));
					newMbo.setValue("utilization", exitData.getCurrentData("UTILIZATION"));
					newMbo.setValue("frpcqty", qty);
					newMbo.setValue("frpcum", uom);
					newMbo.setValue("legalin", legalin);
					newMbo.setValue("outgrant", outgrant);
					newMbo.setValue("zipcode", exitData.getCurrentData("ZIPCODE"));
					newMbo.setValue("typeflag", type_flag);
					//langcode
					fbmslocholdSet.save();
					fbmslocholdSet.close();
					MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...after calling fbmslocholdSet.save()");
				}
				
				if (type_flag.equalsIgnoreCase("x")) {
					MboSetRemote locationSet2 = getMboSet("LOCATIONS");
					locationSet2.setWhere("LOCATION = '"+maximoid+"' and SITEID = '"+siteid+"'");
					locationSet2.reset();
					if (locationSet2.count() > 0) {
						for (int k = 0; k < locationSet2.count(); k++) {
							MboRemote location = locationSet2.getMbo(k);
							Calendar currentCal = new GregorianCalendar();
							SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
							if (!exitData.isCurrentDataNull("ACQDATE")) {
								Date newDate = formatter.parse(exitData.getCurrentDataAsString("ACQDATE"));
								Date newDate2 = MXFormat.getDateOnly(newDate);
								location.setValue("acquisitiondate", newDate2);
							}
							//SR 27602, cpatel
							//location.setValue("description", exitData.getCurrentData("DESCRIPTION"));
							location.setValue("status", locstat, 11L);
							location.setValue("yearbuilt", exitData.getCurrentData("YEARBUILT"));
							location.setValue("respcostctr", exitData.getCurrentData("RESPCOSTCENTER"));
							location.setValue("respcostctrname", exitData.getCurrentData("RESPCOSTCENTERNAME"));
							locationSet2.save();
						}
						locationSet2.close();
						MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...after calling locationSet2.save()");
					}
					if (!locstat.equalsIgnoreCase(locstatus)) {
						MboSetRemote locationSet3 = getMboSet("LOCATIONS");
						locationSet3.setWhere("LOCATION = '"+maximoid+"' and SITEID = '"+siteid+"'");
						locationSet3.reset();
						if (!locationSet3.isEmpty()) {
							MboRemote location = locationSet3.getMbo(0);
							MboSetRemote locStatusSet = location.getMboSet("LOCSTATUS");
							MboRemote newMbo = locStatusSet.add();
							newMbo.setValue("location", maximoid);
							newMbo.setValue("status", locstat, 11L);
							newMbo.setValue("changeby", !exitData.isCurrentDataNull("CHANGEBY") ? exitData.getCurrentData("CHANGEBY") : "MAXADMIN");
							newMbo.setValue("changedate", !exitData.isCurrentDataNull("CHANGEDATE") ? exitData.getCurrentDataAsDate("CHANGEDATE") : MXServer.getMXServer().getDate());
							newMbo.setValue("memo", "UPDATED VIA FBMSIF505");
							newMbo.setValue("siteid", siteid);
							newMbo.setValue("orgid", "NPS");
							locStatusSet.save();
							locStatusSet.close();
							MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...after calling locationSet.save()");
						}
					}
					MboSetRemote frppSet = getMboSet("FRPP");
					frppSet.setWhere("LOCATION = '"+maximoid+"' and SITEID = '"+siteid+"'");
					frppSet.reset();
					if (frppSet.count() > 0) {
						for (int l = 0; l < frppSet.count(); l++) {
							MboRemote frpp = frppSet.getMbo(l);
							frpp.setValue("createby", exitData.getCurrentData("CREATEBY"));
							//Added validation, cpatel
							if(!exitData.isCurrentDataNull("CREATEDATE"))
								frpp.setValue("createdate", exitData.getCurrentDataAsDate("CREATEDATE"));
							//SR 27602, cpatel
							//frpp.setValue("description", exitData.getCurrentData("DESCRIPTION"));
							Calendar currentCal = new GregorianCalendar();
							SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
							if (!exitData.isCurrentDataNull("DISPOSALDATE")) {
								Date newDate = formatter.parse(exitData.getCurrentData("DISPOSALDATE"));
								Date newDate2 = MXFormat.getDateOnly(newDate);
								frpp.setValue("dispdte", newDate2);
							}
							frpp.setValue("dspmeth", exitData.getCurrentData("DISPOSITIONMETHOD"));
							if (!exitData.isCurrentDataNull("DOIASSETCODE")) {
								frpp.setValue("doicode", exitData.getCurrentData("DOIASSETCODE"));
								//HAQ FRD 2.1.9
								MboSetRemote doicodeSet = frpp.getMboSet("FRPP_DOICODE");
								if (!doicodeSet.isEmpty()) {
									MboRemote doicode = doicodeSet.getMbo(0);
									String preduse = doicode.getString("DESCRIPTION");
									frpp.setValue("preduse", preduse);
								}
							}
								
							if (qty != 0 && (uom != null && !uom.equalsIgnoreCase("")))
								frpp.setValue("frpcqty", qty);
							if (qty != 0 && (uom != null && !uom.equalsIgnoreCase("")))
								frpp.setValue("frpcum", uom);
							if (!exitData.isCurrentDataNull("FRPPIND"))
								frpp.setValue("frppind", exitData.getCurrentDataAsInt("FRPPIND"));
							//hasld = 0,
							frpp.setValue("installationid", exitData.getCurrentData("INSTALLATIONID"));
							frpp.setValue("legacyid", exitData.getCurrentData("LEGACYID"));
							if (legalin != null && !legalin.equals(""))
								frpp.setValue("legalin", legalin);
							frpp.setValue("outgrant", outgrant);
							frpp.setValue("realpropertyid", exitData.getCurrentData("REALPROPERTYID"));
							if (!exitData.isCurrentDataNull("REPORTINGAGENCY"))
								frpp.setValue("agcode", exitData.getCurrentData("REPORTINGAGENCY"));
							if (!exitData.isCurrentDataNull("USINGORG"))
								frpp.setValue("bucode", exitData.getCurrentData("USINGORG"));
							frpp.setValue("annualoperatingcost", exitData.getCurrentDataAsDouble("ANNUALOPERATINGCOST"));
							frpp.setValue("changeby", exitData.getCurrentData("CHANGEBY"));
							//Added validation, cpatel
							if(!exitData.isCurrentDataNull("CHANGEDATE"))
								frpp.setValue("changedate", exitData.getCurrentDataAsDate("CHANGEDATE"));
							frpp.setValue("city", exitData.getCurrentData("CITY"));
							if (!exitData.isCurrentDataNull("CONGDISTRICT"))
								frpp.setValue("congdist", exitData.getCurrentData("CONGDISTRICT"));
							frpp.setValue("congdist2", exitData.getCurrentData("CONGDISTRICT2"));
							frpp.setValue("congdist3", exitData.getCurrentData("CONGDISTRICT3"));
							frpp.setValue("costcenter", exitData.getCurrentData("COSTCENTER"));
							frpp.setValue("county", exitData.getCurrentData("COUNTY"));
							frpp.setValue("disposalobstacle", exitData.getCurrentData("DISPOSALOBSTACLE"));
							frpp.setValue("disposalstatuscode", exitData.getCurrentData("DISPOSALSTATUSCODE"));
							frpp.setValue("fbmsuseremail", exitData.getCurrentData("FBMSUSEREMAIL"));
							frpp.setValue("fbmsuserid", exitData.getCurrentData("FBMSUSERID"));
							if (!exitData.isCurrentDataNull("HISTORICALSTATUS"))
								frpp.setValue("ex14", exitData.getCurrentData("HISTORICALSTATUS"));
							frpp.setValue("state", exitData.getCurrentData("STATE"));
							frpp.setValue("street", exitData.getCurrentData("STREET"));
							if (!exitData.isCurrentDataNull("SUSTAINABILITY"))
								frpp.setValue("ex5", exitData.getCurrentData("SUSTAINABILITY"));
							frpp.setValue("usefullife", exitData.getCurrentData("USEFULLIFE"));
							frpp.setValue("zipcode", exitData.getCurrentData("ZIPCODE"));
							//Check if UTILIZATION element exists in the message. It is missing for many locations. So this check is required. cpatel 11/23/15
							/* HAQ - Remove per FRD 2.1.6
							Element rootNode = userDoc.getRootElement();							
							Iterator itr = rootNode.getDescendants(new ElementFilter("UTILIZATION"));
							while(itr.hasNext()) {
								Element e = (Element)itr.next();
								String currentName = e.getName();
								if(currentName.equals("UTILIZATION"))
								{
									if (!exitData.isCurrentDataNull("UTILIZATION")) {
										
									}
									//frpp.setValue("util", exitData.getCurrentData("UTILIZATION"));								
								}								
							}						
							*/
							frppSet.save();
						}
						frppSet.close();
						MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...after calling frppSet.save()");
					}
				}
				
			}
			
			/*
			if (!resultSet.isClosed())
			{
				resultSet.close();
			}
			if (!stmt.isClosed())
			{
				stmt.close();
			}
			if (!conn.isClosed())
			{
				conn.close();
			}
			*/
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}finally {
			MXServer.getMXServer().getDBManager().freeConnection(userInfo.getConnectionKey());
		}
		
		return exitData;
	}

	public int checkBusinessRules(MboRemote mboremote,
			StructureData structuredata) throws MXException, RemoteException {
		return 1;
	}

	public void setAdditionalData(MboRemote mboremote,
			StructureData structuredata) throws MXException, RemoteException {
	}
	
}
