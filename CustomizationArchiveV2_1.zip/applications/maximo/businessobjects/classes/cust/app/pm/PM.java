package cust.app.pm;

import java.rmi.RemoteException;
import java.util.*;
import psdi.mbo.*;
import psdi.util.*;
import psdi.util.logging.MXLogger;
import psdi.app.asset.AssetRemote;


public class PM extends psdi.app.pm.PM implements psdi.app.pm.PMRemote
{
    public PM(MboSet ms)
        throws MXException, RemoteException
    {
        super(ms);
    }
	
    public void canGenerateWork()
    	throws RemoteException, MXException
    {
		super.canGenerateWork();
		
		if (getString("LOCATION").length()!=0)
		{
			if((getMboSet("LOCATIONS").getMbo(0).getString("status").equals("SITE")) && (getString("worktype").equals("FM"))){
				throw new MXApplicationException("pm", "FMSITE");
			}
		}
		
		
    }
	
	public void appValidate()
    throws MXException, RemoteException
	{	
		/* As per Maximo improvement requirement, user can select Asset and Location for PM. This code generates error when both values are present. CP
		if ((!isNull("assetnum")) && (!isNull("location"))) {
		  throw new MXApplicationException("safety", "CannotSpecifyAssetnumAndLocation");
		}*/
		if ((inChildSubSet()) && (toBeDeleted()))
		{
		  if ((getMboValue("pmnum").isNull()) && (getUserInfo().isInteractive()))
		  {
			String resetVal = getMboValue("pmnum").getPreviousValue().asString();
			setValue("pmnum", resetVal, 10L);
		  }
		  undelete();
		  if (hasHierarchyLink()) {
			setValue("parent", getMboValue("parent").getInitialValue().asString(), 2L);
		  } else {
			setValueNull("parent", 2L);
		  }
		}
		if ((!isNull("storeloc")) && (isNull("storelocsite"))) {
		  throw new MXApplicationException("pm", "NeedStoreroomSite");
		}
		//super.appValidate();
		
		validateFields();
		
		getMboSet("PMSEQUENCE").validate();
		
		updateJpSeqInUse();
		
		getJobPlanToUse();
		if (getOwner() != null)
		{
		  MboRemote owner = getOwner();
		  if ((!toBeAdded()) && ((owner instanceof AssetRemote)) && (!owner.getBoolean("moved")))
		  {
			boolean previouslyMoved = ((Mbo)owner).getMboValue("moved").getInitialValue().asBoolean();
			if (previouslyMoved) {
			  return;
			}
		  }
		  copyNextJobPlan();
		}
	}
	
	private boolean inChildSubSet()
    throws MXException, RemoteException
	{
		MboRemote owningMbo = getOwner();
		return (owningMbo != null) && (owningMbo.isBasedOn("PM"));
	}
	
	public void clearClassification()
    throws RemoteException, MXException
	{
		setValueNull("classstructureid", 18L);
	}

}	

