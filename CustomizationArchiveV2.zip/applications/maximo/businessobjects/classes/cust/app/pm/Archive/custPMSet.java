package psdi.app.pm;

import java.rmi.RemoteException;
import psdi.mbo.*;
import psdi.server.MXServer;
import psdi.server.MaxVarServiceRemote;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class custPMSet extends PMSet
    implements PMSetRemote
{

    public custPMSet(MboServerInterface ms)
        throws MXException, RemoteException
    {
        super(ms);
    }
	
	protected Mbo getMboInstance(MboSet ms) throws MXException, RemoteException
    {
		return new custPM(ms);
	}

}	
