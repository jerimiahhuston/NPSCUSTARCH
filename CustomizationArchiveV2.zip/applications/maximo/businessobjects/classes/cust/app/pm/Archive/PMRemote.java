package cust.app.pm;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.Hashtable;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;


public interface PMRemote

extends psdi.app.pm.PMRemote

{

}
