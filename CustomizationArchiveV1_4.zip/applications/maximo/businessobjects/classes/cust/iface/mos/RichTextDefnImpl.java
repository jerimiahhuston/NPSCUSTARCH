package cust.iface.mos;
import java.rmi.RemoteException;
import java.util.Map;
import psdi.iface.mic.MicSetOut;
import psdi.mbo.MboRemote;
import psdi.util.MXException;
import psdi.iface.mic.MicUtil;
//import psdi.iface.mos.MosDetailInfo;
import psdi.iface.mos.*;


public class RichTextDefnImpl extends MicSetOut
{
public RichTextDefnImpl() throws MXException, RemoteException

{
super();
// TODO Auto-generated constructor stub
}
 public int checkBusinessRules(MboRemote mbo, MosDetailInfo mosDetInfo, Map<String, Object> ovrdColValueMap)
 throws MXException, RemoteException
{
//MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...Inside checkBusinessRules Method");
if(((psdi.mbo.Mbo)mbo).getThisMboSet().getMboSetInfo().getMboValueInfo("DESCRIPTION_LONGDESCRIPTION") != null)
 {
 try
 {
 //MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...Inside If block of method"); 	 
 javax.swing.text.html.HTMLEditorKit kit = new javax.swing.text.html.HTMLEditorKit();
 javax.swing.text.html.HTMLDocument styledDocument = new javax.swing.text.html.HTMLDocument();
 java.io.StringReader reader = new java.io.StringReader(mbo.getString("DESCRIPTION_LONGDESCRIPTION"));//.init(arguments.richText);

 kit.read(reader,styledDocument,0);
 ovrdColValueMap.put("DESCRIPTION_LONGDESCRIPTION",styledDocument.getText(0,styledDocument.getLength()));
 
 //MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...Before the end of If block");
 }
 catch(Exception e)
 {
 e.printStackTrace();
 }
 }
 //MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...Before Return");
return MosConstants.PROCESS;
}
}