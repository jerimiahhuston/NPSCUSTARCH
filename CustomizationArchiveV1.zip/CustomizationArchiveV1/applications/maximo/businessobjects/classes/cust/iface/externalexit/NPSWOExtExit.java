package cust.iface.externalexit;

//import java.io.ByteArrayInputStream;
//import java.io.IOException;
import java.rmi.RemoteException;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import psdi.iface.mic.MicUtil;
import psdi.iface.mic.StructureData;
import psdi.iface.mos.MOSStAXStructure;
//import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.iface.migexits.ExternalExit;

//import psdi.iface.mx6x.UpgradeXMLConverterOut;

import psdi.app.workorder.WOSet;
import psdi.app.workorder.WO;

/**
 * 
 * @author Haq Khan
 *
 */
public class NPSWOExtExit extends ExternalExit {

	public NPSWOExtExit() {
		super();
	}
	

	/**
	 * FBMSIF617 outbound message processing.
	 * Ported TRM Rule for FBMSIF617 to Java.
	 * 
	 * @see cust.iface.externalexit.NPSExternalExit#setDataOut(psdi.iface.mic.StructureData)
	 */
	public StructureData setDataOut(StructureData exitData) throws MXException, RemoteException {
		//HAQ - added for MX 7.5
		exitData.breakData();
		StructureData sData = null;
		MboSetRemote FBMSIF617Set = getMboSet("FBMSIF617");
		MboRemote newMbo = FBMSIF617Set.add();
		newMbo.setValue("wonum", "P"+exitData.getCurrentData("WONUM"));
		//Add null date check first with string 150329 JM
		if (!exitData.isCurrentDataNull("ACTSTART")) {
			newMbo.setValue("actstart", exitData.getCurrentDataAsDate("ACTSTART"));
		}
		//Add null date check first with string 150329 JM
		if (!exitData.isCurrentDataNull("ACTFINISH")) {
			newMbo.setValue("actfinish", exitData.getCurrentDataAsDate("ACTFINISH"));
		}
		System.out.println("NPSWOExtExtExit Temp Debug:  Handling busarea");
		newMbo.setValue("busarea", "P000");
		newMbo.setValue("changeby", exitData.getCurrentData("CHANGEBY"));
		System.out.println("NPSWOExtExtExit Temp Debug:  Handling changedate");
		//Add null date check first with string 150329 JM
		if (!exitData.isCurrentDataNull("CHANGEDATE")) {
			newMbo.setValue("changedate", exitData.getCurrentDataAsDate("CHANGEDATE"));
		}
		//Add null check 150329 JM
		if (!exitData.isCurrentDataNull("REPORTEDBY")) {
			newMbo.setValue("createby", exitData.getCurrentData("REPORTEDBY"));
		}
		//Add null date check first with string 150329 JM
		if (!exitData.isCurrentDataNull("REPORTDATE")) {
			newMbo.setValue("createdate", exitData.getCurrentDataAsDate("REPORTDATE"));
		}
		//Added validation for description length, cpatel
		if (!exitData.isCurrentDataNull("DESCRIPTION")) {
			if (exitData.getCurrentData("DESCRIPTION").length()>40){
				newMbo.setValue("description", exitData.getCurrentData("DESCRIPTION").substring(0, 39)); //FBMSIF617 description is 40 chars max...
			}
			else{
				newMbo.setValue("description", exitData.getCurrentData("DESCRIPTION"));
			}
		}
		MicUtil.INTEGRATIONLOGGER.debug(getClass().getName() + "...after setting description");
		newMbo.setValue("description_longdescription", exitData.getCurrentData("DESCRIPTION_LONGDESCRIPTION"));
		MicUtil.INTEGRATIONLOGGER.debug(getClass().getName() + "...after setting long description");
		if (!exitData.isCurrentDataNull("HASLD")) {
			newMbo.setValue("hasld", exitData.getCurrentDataAsBoolean("HASLD"));
		}
		MicUtil.INTEGRATIONLOGGER.debug(getClass().getName() + "...after setting hasld");
		newMbo.setValue("estlabcost", exitData.getCurrentDataAsDouble("ESTLABCOST"));
		newMbo.setValue("estmatcost", exitData.getCurrentDataAsDouble("ESTMATCOST"));
		newMbo.setValue("estservcost", exitData.getCurrentDataAsDouble("ESTSERVCOST"));
		newMbo.setValue("esttoolcost", exitData.getCurrentDataAsDouble("ESTTOOLCOST"));
		newMbo.setValue("parent", exitData.getCurrentData("PARENT"));
		newMbo.setValue("propertyid", exitData.getCurrentData("PROPERTYID"));
		newMbo.setValue("status", exitData.getCurrentData("STATUS"));
		newMbo.setValue("worktype", "SO");
		newMbo.setValue("woclass", exitData.getCurrentData("WOPM3"));
		newMbo.setValue("transdate", MXServer.getMXServer().getDate());
		FBMSIF617Set.save();
		MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...saved FBMSIF617Set");
		//CreateStructure cs = new CreateStructure("FBMSIF617INTOP", null, this, getUserInfo());
		//sData = cs.create(newMbo);

		//Updated for Maximo 7.5 150402 JM
		sData = new StructureData("Publish", "FBMSIF617INTO","EN", 1, false, false);	
		sData.setCurrentMbo(newMbo);

		//Set values for new StructureData (cannot seem to find automatic way of setting, so setting manually
		sData.setCurrentData("FBMSIF617ID", newMbo.getLong("FBMSIF617ID"));
		if (!exitData.isCurrentDataNull("DESCRIPTION")) {
			if (exitData.getCurrentData("DESCRIPTION").length()>40)
			{
				sData.setCurrentData("DESCRIPTION", exitData.getCurrentData("DESCRIPTION").substring(0, 39));
			}else{
				sData.setCurrentData("DESCRIPTION", exitData.getCurrentData("DESCRIPTION"));
			}
				
		}else{
			sData.setCurrentData("DESCRIPTION", "");
		}
		if (!exitData.isCurrentDataNull("ACTFINISH")) {
			sData.setCurrentData("ACTFINISH", exitData.getCurrentData("ACTFINISH"));
		}else{
			sData.setCurrentData("ACTFINISH", "");
		}
		if (!exitData.isCurrentDataNull("ACTSTART")) {
			sData.setCurrentData("ACTSTART", exitData.getCurrentData("ACTSTART"));
		}else{
			sData.setCurrentData("ACTSTART", "");
		}
		sData.setCurrentData("BUSAREA", "P000");
		if (!exitData.isCurrentDataNull("REPORTEDBY")) {
			sData.setCurrentData("CHANGEBY", exitData.getCurrentData("REPORTEDBY"));
		}else{
			sData.setCurrentData("CHANGEBY", "");
		}
			
		if (!exitData.isCurrentDataNull("REPORTDATE")) {
			sData.setCurrentData("CHANGEDATE", exitData.getCurrentData("REPORTDATE"));
		}else{
			sData.setCurrentData("CHANGEDATE", "");
		}
		sData.setCurrentData("DOIRANKINGSCORE", newMbo.getString("DOIRANKINGSCORE"));
		sData.setCurrentData("ESTLABCOST", exitData.getCurrentData("ESTLABCOST"));
		sData.setCurrentData("ESTMATCOST", exitData.getCurrentData("ESTMATCOST"));
		sData.setCurrentData("ESTTOOLCOST", exitData.getCurrentData("ESTTOOLCOST"));
		sData.setCurrentData("PARENT", exitData.getCurrentData("PARENT"));
		sData.setCurrentData("PROPERTYID", exitData.getCurrentData("PROPERTYID"));
		sData.setCurrentData("RACCODE", newMbo.getString("RACCODE"));
		sData.setCurrentData("STATUS", exitData.getCurrentData("STATUS"));
		sData.setCurrentData("WOCLASS", exitData.getCurrentData("WOPM3"));
		sData.setCurrentData("WONUM", "P"+exitData.getCurrentData("WONUM"));
		sData.setCurrentData("WORKTYPE", "SO");
		sData.setCurrentData("CREATEBY", exitData.getCurrentData("REPORTBY"));
		sData.setCurrentData("CREATEDATE", exitData.getCurrentData("REPORTDATE"));
		if (!exitData.isCurrentDataNull("HASLD")) {
			sData.setCurrentData("HASLD", exitData.getCurrentData("HASLD"));
		}else
		{
			sData.setCurrentData("HASLD", "");
		}
		if (!exitData.isCurrentDataNull("LANGCODE")) {
			sData.setCurrentData("LANGCODE", exitData.getCurrentData("LANGCODE"));
		}else
		{
			sData.setCurrentData("LANGCODE", "");
		}
		
		//End Set values for new StructureData (cannot seem to find automatic way of setting, so setting manually
		
		
		Document userDoc = sData.getData();
		//userDoc = UpgradeXMLConverterOut.convertTo6X(userDoc, false, "FBMSIF617INTO", "FBMSESWO");
		//Removed as message tracking functionality is available in Maximo 7.5, cpatel 7/1/15
		//logOutboundXml(exitData.getMessageID(), userDoc);
		sData = new StructureData(userDoc);
		MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...logged message");
		
		return sData;
	}



	/** 
	 * FBMSIF618 inbound message processing.
	 * Ported DB Trigger MAXIMO.TR_IF618_UPD_WO to Java.
	 * 
	 * @see cust.iface.externalexit.NPSExternalExit#setDataIn(psdi.iface.mic.StructureData)
	 */
	public StructureData setDataIn(StructureData exitData) throws MXException, RemoteException {
		//HAQ - added for MX 7.5
		exitData.breakData();
		Document userDoc = exitData.getData();
		//Removed as message tracking functionality is available in Maximo 7.5, cpatel 7/1/15
		//logInboundXml(exitData.getMessageID(), userDoc);
		MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...logged message");
		
		String woStatus = null;
		String wonum = exitData.getCurrentData("WONUM").substring(1, exitData.getCurrentData("WONUM").length());
		
		exitData.setCurrentData("TRANSDATE", MXServer.getMXServer().getDate());
		
		if (!exitData.isCurrentDataNull("STATUS")) {
			if (exitData.getCurrentData("STATUS").equalsIgnoreCase("REL") || 
					exitData.getCurrentData("STATUS").equalsIgnoreCase("INPRG"))
			{
				woStatus = "FUNDED";
			} else if (exitData.getCurrentData("STATUS").equalsIgnoreCase("CLSD") || 
					exitData.getCurrentData("STATUS").equalsIgnoreCase("CLOSE"))
			{
				woStatus = "CLOSE";
			} else {
				MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...empty STATUS");
				throw new MXApplicationException("iface", "skip_transaction");
			}
		} else {
			MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...The FBMS Status "+
					exitData.getCurrentData("STATUS")+" is not valid for Work Order # "+exitData.getCurrentData("WONUM"));
			throw new MXApplicationException("iface", "skip_transaction");
		}
		
		MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...Processing Work Order");
		MboSetRemote woSet = getMboSet("WORKORDER");
		woSet.setWhere("WONUM = '"+wonum+"' and WORKTYPE = 'RPSO'");
		woSet.reset();
		if (!woSet.isEmpty()) {
			MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...woSet is NOT empty");
			if (woSet.count() > 0) {
				for (int i = 0; i < woSet.count(); i++) {
					//MboRemote wo = woSet.getMbo(i);
					WO wo = (WO)woSet.getMbo(i);
					wo.setValue("CHANGEBY","MAXADMIN");
					wo.setValue("CHANGEDATE",MXServer.getMXServer().getDate());
					wo.setValue("costobject", exitData.getCurrentData("WONUM"));
					wo.setValue("fund", exitData.getCurrentData("FONDS"));
					wo.setValue("funcarea", exitData.getCurrentData("FUNC_AREA"));
					wo.setValue("costcenter", exitData.getCurrentData("FISTL"));
					wo.setValue("wbsnum", exitData.getCurrentData("PSPEL"));
					
					//update costs
					double actconstcost = !exitData.isCurrentDataNull("ACTCONSTCOST") ? 
							exitData.getCurrentDataAsDouble("ACTCONSTCOST") : wo.getDouble("ACTCONSTCOST");
					double actfuelcost = !exitData.isCurrentDataNull("ACTFUELCOST") ? 
							exitData.getCurrentDataAsDouble("ACTFUELCOST") : wo.getDouble("ACTFUELCOST");
					double actloccost = !exitData.isCurrentDataNull("ACTLOCCOST") ? 
							exitData.getCurrentDataAsDouble("ACTLOCCOST") : wo.getDouble("ACTLOCCOST");
					double acttrancost = !exitData.isCurrentDataNull("ACTTRANCOST") ? 
							exitData.getCurrentDataAsDouble("ACTTRANCOST") : wo.getDouble("ACTTRANCOST");
					double acttravcost = !exitData.isCurrentDataNull("ACTTRAVCOST") ? 
							exitData.getCurrentDataAsDouble("ACTTRAVCOST") : wo.getDouble("ACTTRAVCOST");
					double actutilcost = !exitData.isCurrentDataNull("ACTUTILCOST") ? 
							exitData.getCurrentDataAsDouble("ACTUTILCOST") : wo.getDouble("ACTUTILCOST");
					double actftravcost = !exitData.isCurrentDataNull("ACTFTRAVCOST") ? 
							exitData.getCurrentDataAsDouble("ACTFTRAVCOST") : wo.getDouble("ACTFTRAVCOST");
					double actlabcost_fbms = !exitData.isCurrentDataNull("ACTLABCOST") ? 
							exitData.getCurrentDataAsDouble("ACTLABCOST") : wo.getDouble("ACTLABCOST_FBMS");
					double actmatcost_fbms = !exitData.isCurrentDataNull("ACTMATCOST") ? 
							exitData.getCurrentDataAsDouble("ACTMATCOST") : wo.getDouble("ACTMATCOST_FBMS");
					double actservcost_fbms = !exitData.isCurrentDataNull("ACTSERVCOST") ? 
							exitData.getCurrentDataAsDouble("ACTSERVCOST") : wo.getDouble("ACTSERVCOST_FBMS");
					double acttoolcost_fbms = !exitData.isCurrentDataNull("ACTTOOLCOST") ? 
							exitData.getCurrentDataAsDouble("ACTTOOLCOST") : wo.getDouble("ACTTOOLCOST_FBMS");
					double heritage = !exitData.isCurrentDataNull("HERITAGE") ? 
							exitData.getCurrentDataAsDouble("HERITAGE") : wo.getDouble("HERITAGE");
					double stewardship = !exitData.isCurrentDataNull("STEWARDSHIP") ? 
							exitData.getCurrentDataAsDouble("STEWARDSHIP") : wo.getDouble("STEWARDSHIP");
					double acttotcost = actconstcost+actfuelcost+actloccost+acttrancost+acttravcost+
										actutilcost+actftravcost+actlabcost_fbms+actmatcost_fbms+actservcost_fbms+
										acttoolcost_fbms+heritage+stewardship;
					
					wo.setValue("actconstcost", actconstcost);
					wo.setValue("actfuelcost", actfuelcost);
					wo.setValue("actloccost", actloccost);
					wo.setValue("acttrancost", acttrancost);
					wo.setValue("acttravcost", acttravcost);
					wo.setValue("actutilcost", actutilcost);
					wo.setValue("actftravcost", actftravcost);
					wo.setValue("actlabcost_fbms", actlabcost_fbms);
					wo.setValue("actmatcost_fbms", actmatcost_fbms);
					wo.setValue("actservcost_fbms", actservcost_fbms);
					wo.setValue("acttoolcost_fbms", acttoolcost_fbms);
					wo.setValue("heritage", heritage);
					wo.setValue("stewardship", stewardship);
					wo.setValue("acttotcost", acttotcost);
					
					//Implemented changeMaxStatus method, cpatel
					//wo.setValue("historyflag", woStatus != null && woStatus.equalsIgnoreCase("CLOSE") ? 1 : 0, 11L);
					
					if (!woStatus.equalsIgnoreCase(wo.getString("STATUS"))) {
						String memo = "AUTOMATIC STATUS CHANGE FROM FBMSIF618";
						wo.changeStatus(woStatus, MXServer.getMXServer().getDate(), memo);
						//wo.setValue("status", woStatus, 11L);
						//wo.setValue("statusdate",MXServer.getMXServer().getDate());
					}
				}
				woSet.save();
				woSet.close();
				
				MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...after completing woSet.save()");
				/*
				MboSetRemote wostatusSet = woSet.getMbo(0).getMboSet("WOSTATUS");
				MboRemote wostatus = wostatusSet.add();
				MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...after completing wostatus.add()");
				wostatus.setValue("wonum", wonum);
				wostatus.setValue("status", woStatus, 11L);
				wostatus.setValue("changedate", MXServer.getMXServer().getDate());
				wostatus.setValue("changeby", "MAXADMIN");
				wostatus.setValue("memo", "AUTOMATIC STATUS CHANGE FROM FBMSIF618");
				wostatus.setValue("orgid", "NPS");
				wostatus.setValue("siteid", woSet.getMbo(0).getString("SITEID"));
				
				wostatusSet.save();
				wostatusSet.close();
				woSet.close();
				MicUtil.INTEGRATIONLOGGER.info(getClass().getName() + "...after completing wostatus.save()");
				*/
			}
		}
		
		
		return exitData;
	}



	public int checkBusinessRules(MboRemote arg0, StructureData arg1) throws MXException, RemoteException {
		return 1;
	}

	public void setAdditionalData(MboRemote arg0, StructureData arg1) throws MXException, RemoteException {
		
	}

}
