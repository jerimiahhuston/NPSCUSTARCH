package psdi.app.pm;

import java.rmi.RemoteException;
import java.util.*;
import psdi.mbo.*;
import psdi.util.*;
import psdi.util.logging.MXLogger;


public class custPM extends PM implements PMRemote
{
    public custPM(MboSet ms)
        throws MXException, RemoteException
    {
        super(ms);
    }
	
	 public void canGenerateWork()
     throws RemoteException, MXException
    {
		super.canGenerateWork();

		if((getMboSet("LOCATIONS").getMbo(0).getString("status").equals("SITE")) && (getString("worktype").equals("FM"))){
			throw new MXApplicationException("pm", "FMSITE");
		}
		
		
    }
}	

