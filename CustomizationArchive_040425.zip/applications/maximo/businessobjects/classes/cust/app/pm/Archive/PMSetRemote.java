package cust.app.pm;

import java.rmi.RemoteException;

import psdi.mbo.MboSetRemote;

import psdi.util.MXException;

public interface PMSetRemote

extends psdi.app.pm.PMSetRemote


{

}
