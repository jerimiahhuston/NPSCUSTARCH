package cust.app.pm;

import java.rmi.RemoteException;
import psdi.mbo.*;
import psdi.server.MXServer;
import psdi.server.MaxVarServiceRemote;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class PMSet extends psdi.app.pm.PMSet
    implements psdi.app.pm.PMSetRemote
{

    public PMSet(MboServerInterface ms)
        throws MXException, RemoteException
    {
        super(ms);
    }
	
	protected Mbo getMboInstance(MboSet ms) throws MXException, RemoteException
    {
		return new PM(ms);
	}

}	
