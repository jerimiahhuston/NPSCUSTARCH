package nps.webclient.beans.workorder;

import com.ibm.tivoli.maximo.appt.beans.ApptBookAppBean;
import java.rmi.RemoteException;
import psdi.util.MXException;
import psdi.webclient.beans.workorder.WorkorderAppBean;
import psdi.webclient.system.beans.DataBean;

public class NPSWorkorderAppBean 
  extends WorkorderAppBean
{
 public void initializeApp() 
   throws MXException, RemoteException
 {
   DataBean resultsBean = this.app.getResultsBean();
   
   resultsBean.setQbe("ISPST", "N");
   super.initializeApp();
 }
}