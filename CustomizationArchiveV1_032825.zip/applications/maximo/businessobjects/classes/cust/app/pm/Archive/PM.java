package cust.app.pm;

import java.rmi.RemoteException;
import java.util.*;
import psdi.mbo.*;
import psdi.util.*;
import psdi.util.logging.MXLogger;


public class PM extends psdi.app.pm.PM implements psdi.app.pm.PMRemote
{
    public PM(MboSet ms)
        throws MXException, RemoteException
    {
        super(ms);
    }
	
    public void canGenerateWork()
    	throws RemoteException, MXException
    {
		super.canGenerateWork();
		
		if (getString("LOCATION").length()!=0)
		{
			if((getMboSet("LOCATIONS").getMbo(0).getString("status").equals("SITE")) && (getString("worktype").equals("FM"))){
				throw new MXApplicationException("pm", "FMSITE");
			}
		}
		
		
    }
}	

