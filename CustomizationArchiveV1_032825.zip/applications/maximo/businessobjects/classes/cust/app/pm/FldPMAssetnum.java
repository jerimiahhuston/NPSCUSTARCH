package cust.app.pm;

import java.rmi.RemoteException;
import psdi.mbo.Mbo;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.util.MXException;

public class FldPMAssetnum extends psdi.app.pm.FldPMAssetnum 
{
	
    public FldPMAssetnum(MboValue mbv)
            throws MXException
	{
    	super(mbv);
	}
    
	/** 
	*	Update getList() return to include location if it is not null
	*
	*	@exception MXException - MAXIMO exception
	*	@exception RemoteException - Remote exception
	*/
    public MboSetRemote getList()
            throws MXException, RemoteException
    {
        Mbo theMbo = getMboValue().getMbo();
        
        if(theMbo.isZombie())
        {
            setListCriteria("");
        }
        else
        {
	        String location = theMbo.getString("location");
	        String status = getTranslator().toExternalList("LOCASSETSTATUS", "DECOMMISSIONED");
	        setListCriteria((new StringBuilder()).append("status not in (").append(status).append(")").toString());
	        
	        if(location != null && location != "")
	            setListCriteria(getListCriteria().toString() + " and location = '" + location + "'" );
        }
        return super.getList();
    }
}